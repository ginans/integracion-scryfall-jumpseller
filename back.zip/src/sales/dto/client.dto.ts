export interface ClientDto {
  legalCode: string;
  fileid: string;
  name: string;
  address: string;
  district: string;
  email: string;
  business: string;
  rubroId: string;
  giro: string;
  city: string;
}
